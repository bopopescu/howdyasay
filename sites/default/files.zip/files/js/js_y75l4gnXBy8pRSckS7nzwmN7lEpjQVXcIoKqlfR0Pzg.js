/**
 * @file
 * Provides an interface for the MediaRecorder API.
 */

(function ($) {
  'use strict';

  Drupal.MediaRecorder = function (id, conf) {
    var settings = conf;
    var origin = window.location.origin || window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');

    var $element = $('#' + id);
    var $inputFid = $('#' + id + '-fid');
    var $statusWrapper = $element.find('.media-recorder-status');
    var $previewWrapper = $element.find('.media-recorder-preview');
    var $progressWrapper = $element.find('.media-recorder-progress');
    var $video = $element.find('.media-recorder-video');
    var $audio = $element.find('.media-recorder-audio');
    var $meter = $element.find('.media-recorder-meter');
    var $startButton = $element.find('.media-recorder-enable');
    var $recordButton = $element.find('.media-recorder-record');
    var $stopButton = $element.find('.media-recorder-stop');
    var $playButton = $element.find('.media-recorder-play');
    var $settingsButton = $element.find('.media-recorder-settings');
    var $videoButton = $element.find('.media-recorder-enable-video');
    var $audioButton = $element.find('.media-recorder-enable-audio');

    var recording = false;
    var audioContext = null;
    var canvasContext = null;
    var visualizerProcessor = null;
    var freqData = null;
    var volume = 0;
    var barWidth = 0;
    var level = 0;
    var meterProcessor = null;
    var localStream = null;
    var recorder = null;
    var recordURL = null;
    var playbackURL = null;
    var format = null;
    var mimetype = null;
    var analyser = null;
    var microphone = null;
    var blobs = [];
    var blobCount = 0;
    var statusInterval = null;
    var constraints = {};

    // Initial state.
    $recordButton[0].disabled = false;
    $recordButton.hide();
    $stopButton.hide();
    $playButton.hide();
    $settingsButton.hide();
    $video.hide();
    $audio.hide();
    $meter.hide();
    $videoButton.hide();
    $audioButton.hide();
    $previewWrapper.hide();
    $progressWrapper.hide();

    // Set constraints.
    constraints.audio = true;
    constraints.video = {};
    if (settings.constraints.video) {
      constraints.video = {
        width: {
          min: settings.constraints.video_width.min,
          ideal: settings.constraints.video_width.ideal,
          max: settings.constraints.video_width.max
        },
        height: {
          min: settings.constraints.video_height.min,
          ideal: settings.constraints.video_height.ideal,
          max: settings.constraints.video_height.max
        }
      };
    }

    // Show file preview if file exists.
    if (conf.file) {
      var file = conf.file;
      switch (file.type) {
        case 'video':
          $previewWrapper.show();
          $video.show();
          $audio.hide();
          $video[0].src = file.url;
          $video[0].muted = '';
          $video[0].controls = 'controls';
          $video[0].load();
          break;
        case 'audio':
          $previewWrapper.show();
          $audio.show();
          $video.hide();
          $audio[0].src = file.url;
          $audio[0].muted = '';
          $audio[0].controls = 'controls';
          $audio[0].load();
          break;
      }
    }

    initializeButtons();
    initializeEvents();
    setStatus('Click \'Start\' to enable your mic & camera.');

    /**
     * Set status message.
     */
    function setStatus(message) {
      $element.trigger('status', message);
    }

    /**
     * Create volume meter canvas element that uses getUserMedia stream.
     */
    function createVolumeMeter() {

      // Private function for determining current volume.
      function getVolume() {
        var values = 0;
        var length = freqData.length;

        for (var i = 0; i < length; i++) {
          values += freqData[i];
        }

        return values / length;
      }

      canvasContext = $meter[0].getContext("2d");
      meterProcessor = audioContext.createScriptProcessor(1024, 1, 1);
      microphone.connect(analyser);
      analyser.connect(meterProcessor);
      meterProcessor.connect(audioContext.destination);
      meterProcessor.onaudioprocess = function () {
        freqData = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(freqData);
        volume = getVolume();
        level = Math.max.apply(Math, freqData);

        if (volume === 0) {
          $meter.addClass('muted');
        }
        else {
          $meter.removeClass('muted');
        }

        canvasContext.clearRect(0, 0, $meter[0].width, $meter[0].height);
        canvasContext.fillStyle = '#00ff00';
        canvasContext.fillRect(0, 0, $meter[0].width * (level / 255), $meter[0].height);
      };
    }

    /**
     * Create audio visualizer canvas element that uses getUserMedia stream.
     */
    function createAudioVisualizer() {

      // Private function for determining current volume.
      function getVolume() {
        var values = 0;
        var length = freqData.length;

        for (var i = 0; i < length; i++) {
          values += freqData[i];
        }

        return values / length;
      }

      canvasContext = $meter[0].getContext("2d");

      visualizerProcessor = audioContext.createScriptProcessor(1024, 1, 1);
      microphone.connect(analyser);
      analyser.connect(visualizerProcessor);
      visualizerProcessor.connect(audioContext.destination);

      visualizerProcessor.onaudioprocess = function () {
        freqData = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(freqData);
        volume = getVolume();
        barWidth = Math.ceil($meter[0].width / (analyser.frequencyBinCount * 0.5));

        if (volume === 0) {
          $meter.addClass('muted');
        }
        else {
          $meter.removeClass('muted');
        }

        canvasContext.clearRect(0, 0, $meter[0].width, $meter[0].height);
        for (var i = 0; i < analyser.frequencyBinCount; i++) {
          canvasContext.fillStyle = 'hsl(' + i / analyser.frequencyBinCount * 360 + ', 100%, 50%)';
          if ((barWidth * i) + barWidth < $meter[0].width) {
            canvasContext.fillRect(barWidth * i, $meter[0].height, barWidth - 1, -(Math.floor((freqData[i] / 255) * $meter[0].height)));
          }
        }
      };
    }

    /**
     * Toggle to recording preview.
     */
    function recordingPreview() {
      if (constraints.video) {
        $video.show();
        $audio.hide();
        $video[0].src = recordURL;
        $video[0].muted = 'muted';
        $video[0].controls = '';
        $video[0].load();
        $video[0].play();
        $meter.height(20);
      }
      else {
        $video.hide();
        $audio.hide();
        $meter.height($meter.width() / 2);
      }
    }

    /**
     * Toggle to recording preview.
     */
    function playbackPreview() {
      if (blobs.length === 0) {
        return;
      }
      if (constraints.video) {
        playbackURL = URL.createObjectURL(new Blob(blobs, {type: mimetype}));
        $video.show();
        $audio.hide();
        $video[0].src = playbackURL;
        $video[0].muted = '';
        $video[0].controls = 'controls';
        $video[0].load();
      }
      else {
        playbackURL = URL.createObjectURL(new Blob(blobs, {type: mimetype}));
        $audio.show();
        $audio[0].src = playbackURL;
        $audio[0].load();
      }
    }

    /**
     * Stop user media stream.
     */
    function stopStream() {
      if (analyser) {
        analyser.disconnect();
      }
      if (microphone) {
        microphone.disconnect();
      }
      if (localStream) {
        localStream.stop();
      }
      $previewWrapper.hide();
      $startButton.show();
      $recordButton.hide();
      $stopButton.hide();
      $videoButton.hide();
      $audioButton.hide();
      setStatus('Click \'Start\' to enable your mic & camera.');
    }

    /**
     * Start user media stream.
     */
    function startStream() {
      if (localStream) {
        stopStream();
      }
      navigator.getUserMedia(
        constraints,
        function (stream) {
          localStream = stream;
          recorder = new MediaRecorder(localStream);
          recordURL = URL.createObjectURL(localStream);
          format = constraints.video ? 'webm' : 'ogg';
          mimetype = constraints.video ? 'video/webm' : 'audio/ogg';
          audioContext = new AudioContext();
          analyser = audioContext.createAnalyser();
          analyser.smoothingTimeConstant = 0.75;
          analyser.fftSize = 512;
          microphone = audioContext.createMediaStreamSource(stream);

          $previewWrapper.show();
          $meter.show();
          $startButton.hide();
          $videoButton.hide();
          $audioButton.hide();
          $recordButton.show();
          $stopButton.hide();
          recordingPreview();

          if (constraints.video) {
            createVolumeMeter();
          }
          else {
            createAudioVisualizer();
          }

          setStatus('Press record to start recording.');
        },
        function (error) {
          stopStream();
          alert("There was a problem accessing your camera or mic. Please click 'Allow' at the top of the page.");
        }
      );
    }

    /**
     * Enable mic or camera.
     */
    function start() {
      if (settings.constraints.audio && !settings.constraints.video) {
        constraints = {
          audio: true,
          video: false
        };
        startStream();
      }
      else if (!settings.constraints.audio && settings.constraints.video) {
        startStream();
      }
      else {
        $startButton.hide();
        $videoButton.show();
        $audioButton.show();
        setStatus('Record with audio or video?');
      }
    }

    /**
     * Stop recording and trigger stopped event.
     */
    function stop() {
      recorder.stop();
      $element.trigger('recordStop');
    }

    /**
     * Start recording and trigger recording event.
     */
    function record() {
      var promises = [];
      blobs = [];
      blobCount = 0;

      // Send blob chunk to server when ondataavailable is triggered.
      recorder.ondataavailable = function (e) {
        var blob = new Blob([e.data], {type: e.data.type || mimetype});
        if (blob.size > 0) {
          blobs.push(blob);
          blobCount++;
          promises.push(new Promise(function (resolve, reject) {
            var formData = new FormData();
            formData.append("blob", blob);
            formData.append("count", blobCount);
            var request = new XMLHttpRequest();
            request.open('POST', origin + Drupal.settings.basePath + 'media_recorder/record/stream/record', true);
            request.onload = function (evt) {
              if (request.status === 200) {
                resolve(request.response);
              }
              else {
                reject(Error(request.statusText));
              }
            };
            request.onerror = function (evt) {
              reject(Error("Error fetching data."));
            };
            request.send(formData);
          }));
        }
      };

      // Notify server that recording has stopped when onstop is triggered.
      recorder.onstop = function (e) {
        Promise.all(promises).then(function (data) {
          var request = new XMLHttpRequest();
          var formData = new FormData();
          formData.append("mediaRecorderUploadLocation", conf.upload_location);
          request.open('POST', origin + Drupal.settings.basePath + 'media_recorder/record/stream/finish', true);
          request.onload = function (evt) {
            var file = JSON.parse(request.response);
            $element.trigger('refreshData', file);
          };
          request.onerror = function (evt) {
            alert('There was an issue saving your recording, please try again.');
          };
          request.send(formData);
        }).catch(function (error) {
          alert('There was an issue saving your recording, please try again.');
        });
      };

      // Notify server that recording has started.
      var formData = new FormData();
      formData.append('format', format);
      var request = new XMLHttpRequest();
      request.open('POST', origin + Drupal.settings.basePath + 'media_recorder/record/stream/start', true);
      request.onload = function (evt) {
        if (request.status === 200) {
          recorder.start(3000);
          $element.trigger('recordStart');
        }
        else {
          alert('There was an issue starting your recording, please try again.');
        }
      };
      request.onerror = function (evt) {
        alert('There was an issue starting your recording, please try again.');
      };
      request.send(formData);
    }

    /**
     * Initialize all control buttons.
     */
    function initializeButtons() {

      // Click handler for enable audio button.
      $startButton.bind('click', function (event) {
        event.preventDefault();
        start();
      });

      // Click handler for record button.
      $recordButton.bind('click', function (event) {
        event.preventDefault();
        $recordButton[0].disabled = true;
        $recordButton.hide();
        $stopButton.show();
        record();
      });

      // Click handler for stop button.
      $stopButton.bind('click', function (event) {
        event.preventDefault();
        $stopButton.hide();
        $recordButton.show();
        stop();
      });

      // Click handler for to change to video.
      $videoButton.bind('click', function (event) {
        event.preventDefault();
        setStatus('Allow access at top of page.');
        startStream();
      });

      // Click handler for to change to audio.
      $audioButton.bind('click', function (event) {
        event.preventDefault();
        constraints = {
          audio: true,
          video: false
        };
        setStatus('Allow access at top of page.');
        startStream();
      });

    }

    /**
     * Initialize recorder.
     */
    function initializeEvents() {

      // Stop page unload if there is a recording in process.
      window.onbeforeunload = function () {
        if (recording) {
          return 'You are still in the process of recording, are you sure you want to leave this page?';
        }
        else {
          return null;
        }
      };

      // Listen for the record event.
      $element.bind('recordStart', function (event, data) {
        var currentSeconds = 0;
        var timeLimitFormatted = millisecondsToTime(new Date(parseInt(settings.time_limit, 10) * 1000));

        recording = true;
        recordingPreview();
        setStatus('Recording 00:00 (Time Limit: ' + timeLimitFormatted + ')');

        $progressWrapper.show();
        var $progress = $progressWrapper.children('.progress-bar');
        $progress.css({
          width: '0%'
        });

        currentSeconds = 0;
        statusInterval = setInterval(function () {
          currentSeconds = currentSeconds + 1;
          var currentMilliSeconds = new Date(currentSeconds * 1000);
          var time = millisecondsToTime(currentMilliSeconds);
          var timePercentage = currentSeconds / settings.time_limit * 100;

          $progress.css({
            width: timePercentage + '%'
          });

          setStatus('Recording ' + time + ' (Time Limit: ' + timeLimitFormatted + ')');

          if (currentSeconds >= settings.time_limit) {
            stop();
          }
        }, 1000);
      });

      // Listen for the stop event.
      $element.bind('recordStop', function (event) {
        clearInterval(statusInterval);
        $progressWrapper.hide();
        setStatus('Please wait while the recording finishes uploading...');
      });

      // Append file object data.
      $element.bind('refreshData', function (event, data) {
        recording = false;
        $inputFid.val(data.fid);
        $recordButton[0].disabled = false;
        playbackPreview();
        setStatus('Press record to start recording.');
      });

      $element.bind('status', function (event, msg) {
        $statusWrapper.text(msg);
      });
    }

    /**
     * Convert milliseconds to time format.
     */
    function millisecondsToTime(milliSeconds) {
      var milliSecondsDate = new Date(milliSeconds);
      var mm = milliSecondsDate.getMinutes();
      var ss = milliSecondsDate.getSeconds();
      if (mm < 10) {
        mm = "0" + mm;
      }
      if (ss < 10) {
        ss = "0" + ss;
      }
      return mm + ':' + ss;
    }
  };
})(jQuery);
;
/**
 * @file
 * Provides an interface for the Recorder.js library.
 */

(function ($) {
  'use strict';

  Drupal.MediaRecorderHTML5 = function (id, conf) {
    var settings = conf;
    var origin = window.location.origin || window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');

    var $element = $('#' + id);
    var $inputFid = $('#' + id + '-fid');
    var $statusWrapper = $element.find('.media-recorder-status');
    var $previewWrapper = $element.find('.media-recorder-preview');
    var $progressWrapper = $element.find('.media-recorder-progress');
    var $video = $element.find('.media-recorder-video');
    var $audio = $element.find('.media-recorder-audio');
    var $meter = $element.find('.media-recorder-meter');
    var $startButton = $element.find('.media-recorder-enable');
    var $recordButton = $element.find('.media-recorder-record');
    var $stopButton = $element.find('.media-recorder-stop');
    var $playButton = $element.find('.media-recorder-play');
    var $settingsButton = $element.find('.media-recorder-settings');
    var $videoButton = $element.find('.media-recorder-enable-video');
    var $audioButton = $element.find('.media-recorder-enable-audio');

    var recording = false;
    var audioContext = null;
    var canvasContext = null;
    var visualizerProcessor = null;
    var freqData = null;
    var volume = 0;
    var barWidth = 0;
    var level = 0;
    var meterProcessor = null;
    var localStream = null;
    var recorder = null;
    var recordURL = null;
    var playbackURL = null;
    var mimetype = null;
    var analyser = null;
    var microphone = null;
    var blobs = [];
    var statusInterval = null;
    var constraints = {};

    // Initial state.
    $recordButton.hide();
    $stopButton.hide();
    $playButton.hide();
    $settingsButton.hide();
    $video.hide();
    $audio.hide();
    $meter.hide();
    $videoButton.hide();
    $audioButton.hide();
    $previewWrapper.hide();
    $progressWrapper.hide();

    // Show file preview if file exists.
    if (conf.file) {
      var file = conf.file;
      switch (file.type) {
        case 'video':
          $previewWrapper.show();
          $video.show();
          $audio.hide();
          $video[0].src = file.url;
          $video[0].muted = '';
          $video[0].controls = 'controls';
          $video[0].load();
          break;
        case 'audio':
          $previewWrapper.show();
          $audio.show();
          $video.hide();
          $audio[0].src = file.url;
          $audio[0].muted = '';
          $audio[0].controls = 'controls';
          $audio[0].load();
          break;
      }
    }

    initializeButtons();
    initializeEvents();
    setStatus('Click \'Start\' to enable your mic & camera.');

    /**
     * Set status message.
     */
    function setStatus(message) {
      $element.trigger('status', message);
    }

    /**
     * Create volume meter canvas element that uses getUserMedia stream.
     */
    function createVolumeMeter() {
      canvasContext = $meter[0].getContext("2d");
      meterProcessor = audioContext.createScriptProcessor(1024, 1, 1);
      microphone.connect(analyser);
      analyser.connect(meterProcessor);
      meterProcessor.connect(audioContext.destination);
      meterProcessor.onaudioprocess = function () {
        freqData = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(freqData);
        level = Math.max.apply(Math, freqData);
        canvasContext.clearRect(0, 0, $meter[0].width, $meter[0].height);
        canvasContext.fillStyle = '#00ff00';
        canvasContext.fillRect(0, 0, $meter[0].width * (level / 255), $meter[0].height);
      };
    }

    /**
     * Create audio visualizer canvas element that uses getUserMedia stream.
     */
    function createAudioVisualizer() {

      // Private function for determining current volume.
      function getVolume() {
        var values = 0;
        var length = freqData.length;

        for (var i = 0; i < length; i++) {
          values += freqData[i];
        }

        return values / length;
      }

      canvasContext = $meter[0].getContext("2d");

      visualizerProcessor = audioContext.createScriptProcessor(1024, 1, 1);
      microphone.connect(analyser);
      analyser.connect(visualizerProcessor);
      visualizerProcessor.connect(audioContext.destination);

      visualizerProcessor.onaudioprocess = function (audioProcessingEvent) {
        freqData = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(freqData);
        volume = getVolume();

        if (volume === 0) {
          $meter.addClass('muted');
        }
        else {
          $meter.removeClass('muted');
        }

        barWidth = Math.ceil($meter[0].width / (analyser.frequencyBinCount * 0.5));
        canvasContext.clearRect(0, 0, $meter[0].width, $meter[0].height);
        for (var i = 0; i < analyser.frequencyBinCount; i++) {
          canvasContext.fillStyle = 'hsl(' + i / analyser.frequencyBinCount * 360 + ', 100%, 50%)';
          if ((barWidth * i) + barWidth < $meter[0].width) {
            canvasContext.fillRect(barWidth * i, $meter[0].height, barWidth - 1, -(Math.floor((freqData[i] / 255) * $meter[0].height)));
          }
        }
      };
    }

    /**
     * Toggle to recording preview.
     */
    function recordingPreview() {
      if (constraints.video) {
        $video.show();
        $audio.hide();
        $video[0].src = recordURL;
        $video[0].muted = 'muted';
        $video[0].controls = '';
        $video[0].load();
        $video[0].play();
        $meter.height(10);
      }
      else {
        $video.hide();
        $audio.hide();
        $meter.height($meter.width() / 2);
      }
    }

    /**
     * Toggle to recording preview.
     */
    function playbackPreview() {
      if (blobs.length === 0) {
        return;
      }
      if (constraints.video) {
        playbackURL = URL.createObjectURL(new Blob(blobs, {type: mimetype}));
        $video.show();
        $audio.hide();
        $video[0].src = playbackURL;
        $video[0].muted = '';
        $video[0].controls = 'controls';
        $video[0].load();
      }
      else {
        playbackURL = URL.createObjectURL(new Blob(blobs, {type: mimetype}));
        $audio.show();
        $audio[0].src = playbackURL;
        $audio[0].load();
      }
    }

    /**
     * Send a blob as form data to the server. Requires jQuery 1.5+.
     */
    function sendBlob(blob, count) {

      // Create formData object.
      var formData = new FormData();
      var request = new XMLHttpRequest();
      blobs = [blob];
      formData.append("mediaRecorder", blob);
      formData.append("mediaRecorderUploadLocation", conf.upload_location);

      // Send file.
      request.addEventListener("load", transferComplete, false);
      request.open('POST', origin + Drupal.settings.basePath + 'media_recorder/record/file', true);
      request.send(formData);
      function transferComplete(evt) {
        var file = JSON.parse(request.response);
        $element.trigger('uploadFinished', file);
      }
    }

    /**
     * Stop user media stream.
     */
    function stopStream() {
      if (analyser) {
        analyser.disconnect();
      }
      if (microphone) {
        microphone.disconnect();
      }
      if (localStream) {
        localStream.stop();
      }
      $previewWrapper.hide();
      $startButton.show();
      $recordButton.hide();
      $stopButton.hide();
      setStatus('Click \'Start\' to enable your mic & camera.');
    }

    /**
     * Start user media stream.
     */
    function startStream() {
      if (localStream) {
        stopStream();
      }
      navigator.getUserMedia(
        constraints,
        function (stream) {
          localStream = stream;
          recordURL = URL.createObjectURL(localStream);
          mimetype = settings.constraints.video ? 'video/webm' : 'audio/ogg';
          audioContext = new AudioContext();
          analyser = audioContext.createAnalyser();
          analyser.smoothingTimeConstant = 0.75;
          analyser.fftSize = 512;
          microphone = audioContext.createMediaStreamSource(stream);
          recorder = new Recorder(microphone, {workerPath: Drupal.settings.basePath + Drupal.settings.mediaRecorder.workerPath + '/recorderWorker.js'});

          $previewWrapper.show();
          $meter.show();
          $startButton.hide();
          $recordButton.show();
          $stopButton.hide();
          recordingPreview();

          if (constraints.video) {
            createVolumeMeter();
          }
          else {
            createAudioVisualizer();
          }

          setStatus('Press record to start recording.');
        },
        function (error) {
          stopStream();
          alert("There was a problem accessing your camera or mic. Please click 'Allow' at the top of the page.");
        }
      );
    }

    /**
     * Stop recording and trigger stopped event.
     */
    function start() {
      constraints = {
        audio: true,
        video: false
      };

      startStream();
    }

    /**
     * Stop recording and trigger stopped event.
     */
    function stop() {
      recorder.stop();
      recorder.exportWAV(function (blob) {
        sendBlob(blob);
      });
      recorder.clear();
      $element.trigger('recordStop');
    }

    /**
     * Start recording and trigger recording event.
     */
    function record() {
      recorder.record();
      $element.trigger('recordStart');
    }

    /**
     * Initialize all control buttons.
     */
    function initializeButtons() {

      // Click handler for enable audio button.
      $startButton.bind('click', function (event) {
        event.preventDefault();
        $startButton[0].disabled = true;
        start();
        setStatus('Allow access at top of page.');
      });

      // Click handler for record button.
      $recordButton.bind('click', function (event) {
        event.preventDefault();
        $recordButton[0].disabled = true;
        $recordButton.hide();
        $stopButton.show();
        record();
      });

      // Click handler for stop button.
      $stopButton.bind('click', function (event) {
        event.preventDefault();
        $stopButton.hide();
        $recordButton.show();
        stop();
      });
    }

    /**
     * Initialize recorder.
     */
    function initializeEvents() {

      // Stop page unload if there is a recording in process.
      window.onbeforeunload = function () {
        if (recording) {
          return 'You are still in the process of recording, are you sure you want to leave this page?';
        }
        else {
          return null;
        }
      };

      // Listen for the record event.
      $element.bind('recordStart', function (event, data) {
        var currentSeconds = 0;
        var timeLimitFormatted = millisecondsToTime(new Date(parseInt(settings.time_limit, 10) * 1000));

        recording = true;
        recordingPreview();
        setStatus('Recording 00:00 (Time Limit: ' + timeLimitFormatted + ')');

        $progressWrapper.show();
        var $progress = $progressWrapper.children('.progress-bar');
        $progress.css({
          width: '0%'
        });

        currentSeconds = 0;
        statusInterval = setInterval(function () {
          currentSeconds = currentSeconds + 1;
          var currentMilliSeconds = new Date(currentSeconds * 1000);
          var time = millisecondsToTime(currentMilliSeconds);
          var timePercentage = currentSeconds / settings.time_limit * 100;

          $progress.css({
            width: timePercentage + '%'
          });

          setStatus('Recording ' + time + ' (Time Limit: ' + timeLimitFormatted + ')');

          if (currentSeconds >= settings.time_limit) {
            stop();
          }
        }, 1000);
      });

      // Listen for the stop event.
      $element.bind('recordStop', function (event) {
        $progressWrapper.hide();
        clearInterval(statusInterval);
        setStatus('Uploading, please wait...');
      });

      $element.bind('uploadFinished', function (event, data) {
        recording = false;
        $inputFid.val(data.fid);
        $recordButton[0].disabled = false;
        playbackPreview();
        setStatus('Press record to start recording.');
      });

      $element.bind('status', function (event, msg) {
        $statusWrapper.text(msg);
      });
    }

    /**
     * Convert milliseconds to time format.
     */
    function millisecondsToTime(milliSeconds) {
      var milliSecondsDate = new Date(milliSeconds);
      var mm = milliSecondsDate.getMinutes();
      var ss = milliSecondsDate.getSeconds();
      if (mm < 10) {
        mm = "0" + mm;
      }
      if (ss < 10) {
        ss = "0" + ss;
      }
      return mm + ':' + ss;
    }
  };
})(jQuery);
;
/**
 * @file
 * Provides an interface for the FWRecorder library.
 */

(function ($) {
  'use strict';

  Drupal.MediaRecorderFlash = function (id, conf) {
    var settings = conf;
    var origin = window.location.origin || window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');

    var $element = $('#' + id);
    var $inputFid = $('#' + id + '-fid');
    var $statusWrapper = $element.find('.media-recorder-status');
    var $previewWrapper = $element.find('.media-recorder-preview');
    var $progressWrapper = $element.find('.media-recorder-progress');
    var $video = $element.find('.media-recorder-video');
    var $audio = $element.find('.media-recorder-audio');
    var $meter = $element.find('.media-recorder-meter');
    var $startButton = $element.find('.media-recorder-enable');
    var $recordButton = $element.find('.media-recorder-record');
    var $stopButton = $element.find('.media-recorder-stop');
    var $playButton = $element.find('.media-recorder-play');
    var $settingsButton = $element.find('.media-recorder-settings');
    var $videoButton = $element.find('.media-recorder-enable-video');
    var $audioButton = $element.find('.media-recorder-enable-audio');
    var statusInterval = null;
    var recordingName = id + '-audio';
    var recording = false;

    // Initialize flash recorder.
    if (!$('#flash-wrapper').length) {
      $element.append('<div id="flash-wrapper"><div id="flashcontent"><p>Your browser must have JavaScript enabled and the Adobe Flash Player installed.</p></div></div>');

      window.fwr_event_handler = function (eventName) {
        Drupal.settings.mediaRecorder.elements.forEach(function (info) {
          $('#' + info.id).trigger(eventName, arguments);
        });
      };

      swfobject.embedSWF(
        Drupal.settings.basePath + Drupal.settings.mediaRecorder.swfPath + '/html/recorder.swf?id=' + id,
        'flashcontent',
        1,
        1,
        '11.0.0',
        '',
        {},
        {},
        {'id': 'flashRecorder', 'name': 'flashRecorder'}
      );
    }

    // Initial state.
    $recordButton.hide();
    $recordButton.hide();
    $stopButton.hide();
    $playButton.hide();
    $stopButton.before($playButton);
    $previewWrapper.hide();
    $video.hide();
    $audio.hide();
    $meter.hide();
    $videoButton.hide();
    $audioButton.hide();
    $progressWrapper.hide();

    // Show file preview if file exists.
    if (Drupal.settings.mediaRecorder.file) {
      var file = Drupal.settings.mediaRecorder.file;
      switch (file.type) {
        case 'video':
          $previewWrapper.show();
          $video.show();
          $audio.hide();
          $video[0].src = Drupal.settings.mediaRecorder.file.url;
          $video[0].muted = '';
          $video[0].controls = 'controls';
          $video[0].load();
          break;
        case 'audio':
          $previewWrapper.show();
          $audio.show();
          $video.hide();
          $audio[0].src = Drupal.settings.mediaRecorder.file.url;
          $audio[0].muted = '';
          $audio[0].controls = 'controls';
          $audio[0].load();
          break;
      }
    }

    initializeButtons();
    initializeEvents();
    setStatus('Click \'Start\' to enable your mic & camera.');

    /**
     * Set status message.
     */
    function setStatus(message) {
      $element.trigger('status', message);
    }

    /**
     * Toggle to recording preview.
     */
    function showSettings() {
      FWRecorder.showPermissionWindow({permanent: true});
    }

    /**
     * Send a blob as form data to the server. Requires jQuery 1.5+.
     */
    function sendBlob(blob) {
      setStatus('Uploading, please wait...');

      // Create formData object.
      var formData = new FormData();
      var req = new XMLHttpRequest();
      formData.append("mediaRecorder", blob);
      formData.append("mediaRecorderUploadLocation", conf.upload_location);

      // Send file.
      req.addEventListener("load", transferComplete, false);
      req.open('POST', origin + Drupal.settings.basePath + 'media_recorder/record/file', true);
      req.send(formData);
      function transferComplete(evt) {
        var file = JSON.parse(req.response);
        $element.trigger('uploadFinished', file);
      }
    }

    /**
     * Stop recording and trigger stopped event.
     */
    function start() {
      showSettings('asdf');
    }

    /**
     * Stop recording and trigger stopped event.
     */
    function stop() {
      FWRecorder.stopPlayBack();
      FWRecorder.stopRecording();
    }

    /**
     * Start recording and trigger recording event.
     */
    function record() {
      FWRecorder.record(recordingName);
    }

    /**
     * Initialize all control buttons.
     */
    function initializeButtons() {

      // Click handler for enable button.
      $startButton.bind('click', function (event) {
        event.preventDefault();
        $startButton[0].disabled = true;
        start();
        setStatus('Allow access to your mic in the settings panel.');
      });

      // Click handler for record button.
      $recordButton.bind('click', function (event) {
        event.preventDefault();
        $recordButton[0].disabled = true;
        $recordButton.hide();
        $playButton.hide();
        $stopButton.show();
        record();
      });

      // Click handler for stop button.
      $stopButton.bind('click', function (event) {
        event.preventDefault();
        $stopButton.hide();
        $recordButton.show();
        $playButton.show();
        stop();
      });

      // Click handler for play button.
      $playButton.bind('click', function (event) {
        event.preventDefault();
        $playButton.hide();
        $stopButton.show();
        FWRecorder.playBack(recordingName);
      });

      // Click handler for settings button.
      $settingsButton.bind('click', function (event) {
        event.preventDefault();
        showSettings();
      });
    }

    /**
     * Initialize recorder.
     */
    function initializeEvents() {

      // Stop page unload if there is a recording in process.
      window.onbeforeunload = function () {
        if (recording) {
          return 'You are still in the process of recording, are you sure you want to leave this page?';
        }
        else {
          return null;
        }
      };

      // FWRecorder ready event.
      $element.bind('ready', function (event) {

        // Fix for weird FWRecorder use of window instead of document.
        window['flashRecorder'] = document['flashRecorder'];

        FWRecorder.connect('flashRecorder', 0);
        FWRecorder.recorderOriginalWidth = 1;
        FWRecorder.recorderOriginalHeight = 1;

        if (!FWRecorder.isMicrophoneAccessible()) {
          $startButton.show();
        }
      });

      // FWRecorder microphone_connected event.
      $element.bind('microphone_user_request', function (event) {
        FWRecorder.showPermissionWindow();
      });

      // FWRecorder microphone_connected event.
      $element.bind('microphone_connected', function (event) {
        FWRecorder.configure(22, 50, 0, 4000);
        $startButton.hide();
        $recordButton.show();
        setStatus('Press record to start recording.');
        FWRecorder.observeLevel();
      });

      // FWRecorder microphone_not_connected event.
      $element.bind('microphone_not_connected', function (event) {
        $startButton.show();
        $startButton[0].disabled = false;
        $recordButton.hide();
        setStatus('Click \'Start\' to enable your mic & camera.');
      });

      // FWRecorder no_microphone_found event.
      $element.bind('no_microphone_found', function (event, name, data) {
        $startButton.show();
        $startButton[0].disabled = false;
        $recordButton.hide();
        setStatus('No mic found. Click \'Start\' to enable your mic & camera.');
      });

      // FWRecorder permission_panel_closed event.
      $element.bind('permission_panel_closed', function (event) {
        FWRecorder.defaultSize();
      });

      // FWRecorder observing_level event.
      $element.bind('observing_level', function (event, name, data) {
        $meter.show();
        $meter.height(20);
      });

      // FWRecorder observing_level_stopped event.
      $element.bind('observing_level_stopped', function (event, name, data) {
        $meter.hide();
      });

      // FWRecorder microphone_level event.
      $element.bind('microphone_level', function (event, name, data) {
        var level = data * 100;
        $meter.width(level + '%');
        if (data * 100 <= 70) {
          $meter.css({
            'background': 'green'
          });
        }
        else if (level > 70 && level < 85) {
          $meter.css({
            'background': 'yellow'
          });
        }
        else if (level >= 85) {
          $meter.css({
            'background': 'red'
          });
        }
      });

      // FWRecorder recording event.
      $element.bind('recording', function (event, data) {
        var currentSeconds = 0;
        var timeLimitFormatted = millisecondsToTime(new Date(parseInt(settings.time_limit, 10) * 1000));

        $progressWrapper.show();
        var $progress = $progressWrapper.children('.progress-bar');
        $progress.css({
          width: '0%'
        });

        recording = true;
        setStatus('Recording 00:00 (Time Limit: ' + timeLimitFormatted + ')');

        statusInterval = setInterval(function () {
          currentSeconds = currentSeconds + 1;
          var currentMilliSeconds = new Date(currentSeconds * 1000);
          var time = millisecondsToTime(currentMilliSeconds);
          var timePercentage = currentSeconds / settings.time_limit * 100;

          $progress.css({
            width: timePercentage + '%'
          });

          setStatus('Recording ' + time + ' (Time Limit: ' + timeLimitFormatted + ')');

          if (currentSeconds >= settings.time_limit) {
            stop();
          }
        }, 1000);
      });

      // FWRecorder recording_stopped event.
      $element.bind('recording_stopped', function (event) {
        var blob = FWRecorder.getBlob(recordingName);
        $progressWrapper.hide();
        clearInterval(statusInterval);
        sendBlob(blob);
      });

      // FWRecorder recording_stopped event.
      $element.bind('stopped', function (event) {
        $playButton.show();
        $stopButton.hide();
      });

      $element.bind('uploadFinished', function (event, data) {
        recording = false;
        $inputFid.val(data.fid);
        $recordButton[0].disabled = false;
        setStatus('Press record to start recording.');
      });

      $element.bind('status', function (event, msg) {
        $statusWrapper.text(msg);
      });
    }

    /**
     * Convert milliseconds to time format.
     */
    function millisecondsToTime(milliSeconds) {
      var milliSecondsDate = new Date(milliSeconds);
      var mm = milliSecondsDate.getMinutes();
      var ss = milliSecondsDate.getSeconds();
      if (mm < 10) {
        mm = "0" + mm;
      }
      if (ss < 10) {
        ss = "0" + ss;
      }
      return mm + ':' + ss;
    }

  };
})(jQuery);
;
/**
 * @file
 * Provides JavaScript additions to the media recorder element.
 *
 * This file loads the correct media recorder javascript based on detected
 * features, such as the MediaRecorder API and Web Audio API. It has a flash
 * fallback, and uses the file widget for devices that supports nothing.
 */

(function ($) {
  'use strict';

  // Normalize features.
  navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
  window.AudioContext = window.AudioContext || window.webkitAudioContext || window.mozAudioContext;
  window.URL = window.URL || window.webkitURL;

  // Feature detection.
  var getUserMediaCheck = typeof (navigator.getUserMedia) === 'function';
  var mediaRecorderCheck = typeof (window.MediaRecorder) === 'function';
  var webAudioCheck = typeof (window.AudioContext) === 'function';
  var swfobjectCheck = typeof (window.swfobject) === 'object';
  var flashVersionCheck = swfobjectCheck ? (swfobject.getFlashPlayerVersion().major >= 10) : false;

  // Set recorder type.
  var recorderType = false;
  if (getUserMediaCheck && webAudioCheck && mediaRecorderCheck) {
    recorderType = 'MediaRecorder';
  }
  else if (getUserMediaCheck && webAudioCheck && !mediaRecorderCheck) {
    recorderType = 'MediaRecorderHTML5';
  }
  else if (swfobjectCheck && flashVersionCheck) {
    recorderType = 'MediaRecorderFlash';
  }

  // Attach behaviors.
  Drupal.behaviors.mediaRecorder = {
    attach: function (context, settings) {
      if (settings.mediaRecorder && settings.mediaRecorder.elements) {
        $.each(settings.mediaRecorder.elements, function (key, info) {
          $('#' + info.id, context).once('media-recorder', function () {
            var $mediaRecorder = $('#' + info.id);
            var $mediaRecorderFallback = $('#' + info.id + '-fallback-ajax-wrapper');
            switch (recorderType) {
              case 'MediaRecorder':
                $mediaRecorder.show();
                $mediaRecorderFallback.remove();
                new Drupal.MediaRecorder(info.id, info.conf);
                break;
              case 'MediaRecorderHTML5':
                $mediaRecorder.show();
                $mediaRecorderFallback.remove();
                // Use the kaltura video recorder if kaltura is enabled, rather
                // than the HTML5 audio only Recorder.js library.
                if (info.conf.kaltura) {
                  new Drupal.MediaRecorderFlash(info.id, info.conf);
                }
                else {
                  new Drupal.MediaRecorderHTML5(info.id, info.conf);
                }
                break;
              case 'MediaRecorderFlash':
                $mediaRecorder.show();
                $mediaRecorderFallback.remove();
                new Drupal.MediaRecorderFlash(info.id, info.conf);
                break;
              default:
                $mediaRecorder.hide();
            }
          });
        });
      }
    }
  };
})(jQuery);
;
